package ai.tech5.t5billing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BillingService {

	public static void main(String[] args) {

		SpringApplication.run(BillingService.class, args);
	}
}
