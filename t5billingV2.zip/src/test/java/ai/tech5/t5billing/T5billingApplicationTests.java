package ai.tech5.t5billing;

/*
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class T5billingApplicationTests {

	@Test
	void contextLoads() {
	}

}
*/
